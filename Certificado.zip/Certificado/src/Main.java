public class Main {
    public static void main(String[] args){
        Certificado c= new Certificado("DOC-2026-001");
        ActaNotas n=new ActaNotas("Tecnologia en desarrollo de software");
        HorariAcademico h=new HorariAcademico("2026-A");
        c.imprimir();
        n.imprimir();
        h.imprimir();
    }
}