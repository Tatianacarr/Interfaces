public class HorariAcademico implements Imprimible{
    private String periodoAcademico;
    public HorariAcademico(String periodoAcademico){
        this.periodoAcademico=periodoAcademico;
    }
    @Override
    public void imprimir(){
        System.out.println("Imprimiendo Horario");
        System.out.println("Periodo  Academico:"+periodoAcademico);
    }
}
