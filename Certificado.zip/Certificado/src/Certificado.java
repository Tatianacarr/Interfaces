public class Certificado implements Imprimible{
    private String numeroDocumentos;
    public Certificado(String numeroDocumentos){
        this.numeroDocumentos=numeroDocumentos;
    }
    @Override
    public void imprimir(){
        System.out.println("Imprimiendo el certificado academico");
        System.out.println("Numero de documento:"+numeroDocumentos);
    }
}
