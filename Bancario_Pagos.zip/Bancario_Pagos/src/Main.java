public class Main {
    public static void main(String[] args){
        PagoEfectivo p=new PagoEfectivo();
        PagoTarjeta t=new PagoTarjeta();
        Transferencia r=new Transferencia();
        p.procesarPago(200);
        t.procesarPago(300);
        r.procesarPago(-30);
    }
}