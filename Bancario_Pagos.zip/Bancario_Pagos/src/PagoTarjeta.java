public class PagoTarjeta implements Pagable{
    private double comision=2.5;

    @Override
    public void procesarPago(double monto){
        if(monto<=0){
            System.out.println("El monto es invalido");
        }else {
            double total = monto + comision;
            System.out.println("Monto base:"+monto);
            System.out.println("Comision:"+comision);
            System.out.println("Total:"+total);
        }
        
    }
}
