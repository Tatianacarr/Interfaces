public class PagoEfectivo implements Pagable{
    @Override
    public void procesarPago(double monto){
        if (monto <= 0){
            System.out.println("El monto invalido");
        }else{
            System.out.println("Pago efectivo");
            System.out.println("Monto pagado:"+monto);
        }
    }
}
