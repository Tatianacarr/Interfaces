public class Transferencia implements Pagable{
    private double comision=1.0;
    @Override
    public void procesarPago(double monto){
        if (monto<=0){
            System.out.println("Monto invalido");
        }else{
            double total = monto + comision;
            System.out.println("Monto base:"+monto);
            System.out.println("Comision:"+comision);
            System.out.println("Total:"+total);
        }
    }
}
