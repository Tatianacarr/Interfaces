public interface Autentificable {
    boolean iniciarSesion(String usuarioCorrecto, String claveCorrecta);
}
