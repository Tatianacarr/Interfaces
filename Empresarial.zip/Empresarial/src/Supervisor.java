public class Supervisor implements Autentificable, Reportable {

    private String usuarioCorrecto = "supervisor";
    private String claveCorrecta = "super123";

    @Override
    public boolean iniciarSesion(String usuario, String clave) {

        if (usuario.equals(usuarioCorrecto) && clave.equals(claveCorrecta)) {
            System.out.println("Inicio de sesión exitoso del Supervisor.");
            return true;
        } else {
            System.out.println("Usuario o clave incorrectos.");
            return false;
        }
    }

    @Override
    public void generarReporte() {
        System.out.println("El supervisor generó un reporte de supervisión.");
    }
}