public class Administrador implements Autentificable,Reportable,Gestionable{
    private String usuarioCorrecto="admin";
    private String claveCorrecta="admin123";
    @Override
    public boolean iniciarSesion(String usuarioCorrecto,String claveCorrecta){
        if (usuarioCorrecto.equals(usuarioCorrecto)&&claveCorrecta.equals(claveCorrecta)){
            System.out.println("Inicio de sesion exitoso -Administrador");
            return true;
        }else{
            System.out.println("Credenciales incorrectas");
            return false;
        }
    }
    @Override
    public void generarReporte(){
        System.out.println("Reporte creado");
    }
    @Override
    public void gestionarDatos(){
        System.out.println("Se gestiona la informacion");
    }

}
