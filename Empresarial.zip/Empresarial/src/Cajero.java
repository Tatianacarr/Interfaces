public class Cajero implements Autentificable,Gestionable{
    private String usuarioCorrecto="angui";
    private String claveCorrecta="1234";
    @Override
    public boolean iniciarSesion(String usuarioCorrecto,String claveCorrecta){
        if (usuarioCorrecto.equals(usuarioCorrecto)&&claveCorrecta.equals(claveCorrecta)) {
            System.out.println("Inicio de sesion");
            return true;
        }else{
            System.out.println("Credenciales incorrectas");
            return false;
        }
    }
    @Override
    public void gestionarDatos(){
        System.out.println("Gestionando pagos y clientes");
    }
}
